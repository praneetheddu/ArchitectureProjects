#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "cachesim.h"

counter_t accesses = 0, hits = 0, misses = 0, writebacks = 0;

void cachesim_init(int blocksize, int cachesize, int ways) {
}

void cachesim_access(addr_t physical_addr, int write) {
}

void cachesim_print_stats() {
  printf("%llu, %llu, %llu, %llu\n", accesses, hits, misses, writebacks);
}
